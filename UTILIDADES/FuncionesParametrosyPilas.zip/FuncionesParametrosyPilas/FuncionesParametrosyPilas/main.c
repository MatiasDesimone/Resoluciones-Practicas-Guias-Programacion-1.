#include <stdio.h>
#include <stdlib.h>
#include "pila.h"


int miprimerFuncion(int num)
{
    printf("ingrese un numero\n");
    scanf("%d", &num);

    return num;
}
void miprimerFuncion2(int *num)
{
    printf("ingrese un numero\n");
    scanf("%d", num);

}

void miprimerFuncionVoid(int num)
{
    printf("ingrese un numero\n");
    scanf("%d", &num);
    printf("Numero: %d\n", num);

}


void apilarDatos (Pila *p)
{
    apilar(p, 10);
    apilar(p, 10);
    apilar(p, 10);
    apilar(p, 10);
    //printf("La pila P dentro de la funcion apilarDatos\n");
    //mostrar(&p);
}



int main()
{

    int numero;
    numero = miprimerFuncion(numero);
    //miprimerFuncionVoid(numero);
    miprimerFuncion2(&numero);
    printf("El numero asignado en la funcion: %i", numero);

    Pila p;
    inicpila(&p);
    apilarDatos(&p);
    printf("La pila P dentro de la funcion main\n");
    mostrar(&p);

    return 0;
}




































